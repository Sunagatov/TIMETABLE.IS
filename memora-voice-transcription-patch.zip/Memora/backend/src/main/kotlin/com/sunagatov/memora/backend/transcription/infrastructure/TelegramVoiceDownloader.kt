package com.sunagatov.memora.backend.transcription.infrastructure

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.sunagatov.memora.backend.config.MemoraProperties
import com.sunagatov.memora.backend.item.model.TelegramVoiceTrace
import java.net.URI
import java.net.URLEncoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.charset.StandardCharsets
import org.springframework.stereotype.Component

data class DownloadedTelegramVoice(
    val bytes: ByteArray,
    val fileName: String,
    val mimeType: String?
)

@Component
class TelegramVoiceDownloader(
    private val properties: MemoraProperties
) {

    private val httpClient = HttpClient.newHttpClient()
    private val mapper = jacksonObjectMapper()

    fun download(trace: TelegramVoiceTrace): DownloadedTelegramVoice {
        val fileId = trace.telegramFileId?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("Telegram voice trace is missing fileId")

        val filePath = resolveFilePath(fileId)
        val response = httpClient.send(
            HttpRequest.newBuilder()
                .uri(URI.create("${baseUrl()}/file/bot${properties.telegramBotToken}/$filePath"))
                .GET()
                .build(),
            HttpResponse.BodyHandlers.ofByteArray()
        )

        if (response.statusCode() !in 200..299) {
            throw IllegalStateException(
                "Telegram file download failed with status ${response.statusCode()}"
            )
        }

        return DownloadedTelegramVoice(
            bytes = response.body(),
            fileName = filePath.substringAfterLast('/'),
            mimeType = trace.mimeType
        )
    }

    private fun resolveFilePath(fileId: String): String {
        val encodedFileId = URLEncoder.encode(fileId, StandardCharsets.UTF_8)
        val response = httpClient.send(
            HttpRequest.newBuilder()
                .uri(URI.create("${baseUrl()}/bot${properties.telegramBotToken}/getFile?file_id=$encodedFileId"))
                .GET()
                .build(),
            HttpResponse.BodyHandlers.ofString()
        )

        if (response.statusCode() !in 200..299) {
            throw IllegalStateException(
                "Telegram getFile failed with status ${response.statusCode()}: ${response.body()}"
            )
        }

        val root = mapper.readTree(response.body())
        if (!root.path("ok").asBoolean(false)) {
            throw IllegalStateException("Telegram getFile returned ok=false: ${response.body()}")
        }

        return root.path("result").path("file_path").asText().takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Telegram getFile response did not contain file_path")
    }

    private fun baseUrl(): String = properties.telegramApiBaseUrl.trimEnd('/')
}
